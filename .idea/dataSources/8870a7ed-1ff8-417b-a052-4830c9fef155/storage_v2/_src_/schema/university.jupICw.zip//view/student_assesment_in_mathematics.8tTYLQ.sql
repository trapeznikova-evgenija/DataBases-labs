CREATE VIEW student_assesment_in_mathematics AS
  SELECT
    `university`.`student`.`surname`      AS `surname`,
    `university`.`assessment`.`assesment` AS `assesment`,
    `university`.`object`.`object_name`   AS `object_name`
  FROM (((`university`.`assessment`
    JOIN `university`.`student`
      ON ((`university`.`assessment`.`id_student` = `university`.`student`.`id_student`))) JOIN `university`.`lesson`
      ON ((`university`.`assessment`.`id_lesson` = `university`.`lesson`.`id_lesson`))) JOIN `university`.`object`
      ON ((`university`.`lesson`.`id_object` = `university`.`object`.`id_object`)))
  WHERE (`university`.`object`.`object_name` = 'Матанализ');


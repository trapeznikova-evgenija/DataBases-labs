CREATE VIEW average_students_grade AS
  SELECT
    `university`.`lesson`.`id_object`             AS `id_object`,
    count(`university`.`assessment`.`id_student`) AS `amount_student`,
    avg(`university`.`assessment`.`assesment`)    AS `average_grades`
  FROM ((((`university`.`lesson`
    JOIN `university`.`group` ON ((`university`.`lesson`.`id_group` = `university`.`group`.`id_group`))) JOIN
    `university`.`student` ON ((`university`.`group`.`id_group` = `university`.`student`.`id_group`))) JOIN
    `university`.`assessment` ON ((`university`.`student`.`id_student` = `university`.`assessment`.`id_student`))) JOIN
    `university`.`object` ON ((`university`.`lesson`.`id_object` = `university`.`object`.`id_object`)))
  GROUP BY `university`.`lesson`.`id_object`
  HAVING (`amount_student` >= 1);


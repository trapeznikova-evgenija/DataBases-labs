CREATE PROCEDURE get_debtors(IN group_name VARCHAR(255))
  BEGIN
#     DECLARE name_group VARCHAR(255);
#     SET name_group = group_name;
    SELECT student.surname, object.object_name  FROM student
    INNER JOIN `group` ON student.id_group = `group`.id_group
    INNER JOIN lesson ON `group`.id_group = lesson.id_group
    INNER JOIN object ON lesson.id_object = object.id_object
    LEFT JOIN assessment ON lesson.id_lesson = assessment.id_lesson
    WHERE `group`.short_group_name = group_name AND student.id_student NOT IN (SELECT assessment.id_student FROM assessment);
  END;


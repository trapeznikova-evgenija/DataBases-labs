CREATE PROCEDURE get_debtors(IN group_name VARCHAR(255))
  BEGIN
    CREATE TEMPORARY TABLE IF NOT EXISTS learner
      AS (SELECT
            lesson.id_lesson, student.id_student
          FROM lesson
            LEFT JOIN `group` ON lesson.id_group = `group`.id_group
            LEFT JOIN student ON `group`.id_group = student.id_group
            LEFT JOIN object ON lesson.id_object = object.id_object
            LEFT JOIN assessment ON lesson.id_lesson = assessment.id_lesson
          WHERE `group`.short_group_name = group_name);
    SELECT
      student.surname, object.object_name
    FROM learner
      LEFT JOIN assessment ON (learner.id_student = assessment.id_student AND assessment.id_lesson = learner.id_lesson)
      LEFT JOIN student ON learner.id_student = student.id_student
      LEFT JOIN lesson ON learner.id_lesson = lesson.id_lesson
      LEFT JOIN object ON lesson.id_object = object.id_object
    WHERE assessment.id_assessment IS NULL;

    DROP TEMPORARY TABLE learner;
  END;

